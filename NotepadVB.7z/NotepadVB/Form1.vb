﻿Imports System
Imports System.IO
Public Class Form1
    Private Sub MenuStrip1_ItemClicked(sender As Object, e As ToolStripItemClickedEventArgs) Handles MenuStrip1.ItemClicked

    End Sub

    Private Sub NewToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles NewToolStripMenuItem.Click
        TextBox1.Text = ""
    End Sub

    Private Sub OpenToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles OpenToolStripMenuItem.Click
        OpenFileDialog1.ShowDialog()
        ReadFile()
    End Sub
    Public Sub ReadFile()
        TextBox1.Text = System.IO.File.ReadAllText(OpenFileDialog1.FileName)
    End Sub

    Public Sub SaveAsFile()
        System.IO.File.WriteAllText(SaveFileDialog1.FileName, TextBox1.Text)
        ToolStripStatusLabel1.Text = "Ready"
    End Sub

    Private Sub SaveAsToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SaveAsToolStripMenuItem.Click
        SaveFileDialog1.ShowDialog()
        ToolStripStatusLabel1.Text = "Saving file..."
        SaveAsFile()

    End Sub

    Private Sub AboutToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AboutToolStripMenuItem.Click
        MessageBox.Show("Made by DoWindows10 aka EpicGamer")
    End Sub
End Class
